package com.pixogram.userservices.exception;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserErrorResponse {
	
	private String message;
	private Integer errorCode;
	private Long timeStamp;
}
