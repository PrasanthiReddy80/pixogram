package com.pixogram.userservices.service;

import java.util.List;

import com.pixogram.userservices.entity.Users;
import com.pixogram.userservices.model.Userdata;

public interface IUserService {

	List<Users> findAllUsers();
	Users findUserById(Integer id);
	void addUser(Users Users);
	boolean updateUser(Users Users);
	boolean deleteUser(Integer id);
	void saveuser(Userdata userdata);
}
