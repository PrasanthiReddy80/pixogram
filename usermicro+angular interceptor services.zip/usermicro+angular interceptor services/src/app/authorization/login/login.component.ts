import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';
import{ UserRegistrationDetails} from 'src/app/model/User-registration';
import { UserRegistrationService } from 'src/app/services/user registration/user-registration.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  errorMessage : string;
  autherized : boolean;

loginid:string;
loginpwd:string;
authorized:boolean;


uesrlist:Array<UserRegistrationDetails>;
  

 


myFormGroup: FormGroup;


  // recieve authentication service in constructor
  // recieve Router service in constructor

  constructor(public auth : AuthenticationService , public router : Router/*, formBuilder : FormBuilder, public ser :UserRegistrationService*/) {

    /*this.errorMessage = "Invalid Credentials!!!";
    this.autherized = true;

    this.myFormGroup = formBuilder.group({

      // members of a anonymous class
      // form controls
      "userid": new  FormControl(""),
      "userpswd":new FormControl(""),
   
 
     
      
      
    }); */
    console.log( " inside constructer");

  }

 /* // method to check Login credentials
  checkLogin(){

    // need a service to authenticate
  this.loginid=this.myFormGroup.controls['userid'].value;
  this.loginpwd=this.myFormGroup.controls['userpswd'].value;

 console.log("hi ")
    if(this.auth.authenticate(this.loginid, this.loginpwd)){
     
        // if user autherized navigate to mymedia component
        this.autherized = true;
        console.log("hi ")
        this.router.navigate(['/mymedia']);
    }
    else
    {
        this.autherized = false;
    }
  
  }*/



  checkLogin(txtLogin : HTMLInputElement, txtPass : HTMLInputElement){
    // need a service to authenticate
    this.auth.authenticate(txtLogin.value, txtPass.value).subscribe(
      // success function
      successData=>{
        console.log("SUCCESS...");
        console.log(successData);
        this.autherized = true;
        this.router.navigate(['/mymedia']);
      },
      // failure function
      failureData => {
        console.log("FAILED!!!");
        this.autherized = false;
      }
    );

    }


  ngOnInit() {
  }

}