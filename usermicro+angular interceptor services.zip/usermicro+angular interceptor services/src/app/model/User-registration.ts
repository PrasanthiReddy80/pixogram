export class UserRegistrationDetails{
  id:number;
    username:string;
    password:string;
  repassword:string;
  // email:string;
  // enabled:boolean;
constructor(username:string,
           password:string,
          repassword:string,
            //  email:string 
           
              ){
                   this.username=username;
                   this.password=password;
                  this.repassword=repassword;
                //  this.email=email;
                  
                 

}

}