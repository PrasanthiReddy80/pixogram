package com.pixogram.commentservice.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.pixogram.commentservice.model.CommentsModel;
import com.pixogram.commentservice.service.ICommentsService;
import com.pixogram.commentservice.entity.Comments;
import com.pixogram.commentservice.exception.CommentErrorResponse;
import com.pixogram.commentservice.exception.CommentNotFoundException;
import com.pixogram.commentservice.model.CommentsData;

@RestController
public class CommentsController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private ICommentsService commentsService;
	
	@GetMapping("/comment")
	public ResponseEntity<CommentsModel> getallcomments(){
		CommentsModel result = new CommentsModel();
		result.setCommentslist(this.commentsService.getall());
		ResponseEntity<CommentsModel> data = new ResponseEntity<CommentsModel>(result, HttpStatus.OK);
		
		return data;
	}
	
	@PostMapping("/comment")
	public boolean save(@RequestBody CommentsData comment) {
		this.commentsService.save(comment);
		return true;
	}
	@GetMapping("/comment/{commentId}")
	public ResponseEntity<CommentsData> getById(@PathVariable Integer commentId){
		CommentsData data = new CommentsData();
		Comments record = new Comments();
		Optional<Comments> comment = this.commentsService.getWithId(commentId);
		if(comment.isPresent())
			record = comment.get();
		else {
			throw new CommentNotFoundException("comment not found");
		}
		data.setComments(record.getComments());
		data.setId(record.getId());
		data.setCreatedOn(record.getCreatedOn());
		data.setUserId(record.getUserId());
		data.setMediaId(record.getMediaId());
		ResponseEntity<CommentsData> result = new ResponseEntity<CommentsData>(data, HttpStatus.OK);
		return result;
	}
	
	
	//update user
	@PutMapping("/comment")
	public boolean update(@RequestBody CommentsData user) {
		
		this.commentsService.updateuser(user);
		return true;
		
	}
	
	@ExceptionHandler  // ~catch
	public ResponseEntity<CommentErrorResponse> productOperationErrorHAndler(Exception ex) {
		// create error object
		CommentErrorResponse error = new CommentErrorResponse(ex.getMessage(), 
															  HttpStatus.BAD_REQUEST.value(), 
															  System.currentTimeMillis());
		ResponseEntity<CommentErrorResponse> response =
										new ResponseEntity<CommentErrorResponse>(error, HttpStatus.NOT_FOUND);
		logger.error("Exception :" + error);
		
		return response;
	}

}
