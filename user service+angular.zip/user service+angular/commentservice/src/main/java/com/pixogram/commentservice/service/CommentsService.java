package com.pixogram.commentservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.commentservice.entity.Comments;
import com.pixogram.commentservice.repository.CommentsRepository;
import com.pixogram.commentservice.model.CommentsData;

@Service
public class CommentsService implements ICommentsService {
	
	@Autowired
	private CommentsRepository commentsRepository;
	
	public List<Comments> getall(){
		List<Comments> records = this.commentsRepository.findAll();
		return records;
		
	}
	
	public void save(CommentsData comment) {
		Comments data = new Comments();
		
		data.setComments(comment.getComments());
		data.setUserId(comment.getUserId());
		data.setMediaId(comment.getMediaId());
		
		this.commentsRepository.save(data);
		
	}
	
	public Optional<Comments> getWithId(Integer id){
		Optional<Comments> record= this.commentsRepository.findById(id);
		return record;
		
	}
	
	public void updateuser(CommentsData comment) {
		Comments data = new Comments();
		data.setId(comment.getId());
		data.setComments(comment.getComments());
		data.setUserId(comment.getUserId());
		data.setMediaId(comment.getMediaId());
		data.setCreatedOn(comment.getCreatedOn());
		this.commentsRepository.save(data);
	}


}
