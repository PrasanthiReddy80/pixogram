package com.pixogram.commentservice.exception;

public class CommentNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CommentNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
