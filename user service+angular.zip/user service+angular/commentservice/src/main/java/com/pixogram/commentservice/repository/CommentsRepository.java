package com.pixogram.commentservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pixogram.commentservice.entity.Comments;

public interface CommentsRepository extends JpaRepository<Comments, Integer> {

}
