import java.util.Random;

public class RandomNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random rand = new Random(); 
  
        int num1 = rand.nextInt(25); 
        int num2 = rand.nextInt(25); 
  
                System.out.println("Random-1: "+num1); 
        System.out.println("Random-2: "+num2);
	}

}
