package com.pixogram.actionservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.actionservice.entity.Actions;
import com.pixogram.actionservice.repository.ActionsRepository;
import com.pixogram.actionservice.model.ActionData;

@Service
public class ActionService implements IActionService {
	
	@Autowired
	private ActionsRepository actionRepository;
	
	public List<Actions> getall(){
		List<Actions> records =this.actionRepository.findAll();
		return records;
		
	}
	
	public void save(ActionData action) {
		Actions data = new Actions();
		data.setMediaId(action.getMediaId());
		data.setStatus(action.getStatus());
		data.setUserId(action.getUserId());
		this.actionRepository.save(data);
		
	}
	
	public Optional<Actions> getWithId(Integer id){
		Optional<Actions> record= this.actionRepository.findById(id);
		return record;
		
	}
	
	public void updateuser(ActionData action) {
		Actions data = new Actions();
		data.setMediaId(action.getMediaId());
		data.setStatus(action.getStatus());
		data.setUserId(action.getUserId());
		data.setId(action.getId());
		this.actionRepository.save(data);
	}

}
