package com.pixogram.actionservice.model;

import java.util.List;

import com.pixogram.actionservice.entity.Actions;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ActionModel {
	
	public List<Actions> actionlist;
}
