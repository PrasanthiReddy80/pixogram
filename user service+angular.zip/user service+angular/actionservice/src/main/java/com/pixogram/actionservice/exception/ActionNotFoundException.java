package com.pixogram.actionservice.exception;

public class ActionNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ActionNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
