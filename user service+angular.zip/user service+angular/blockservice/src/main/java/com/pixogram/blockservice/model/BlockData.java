package com.pixogram.blockservice.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BlockData {

	private Integer userId;

	private Integer blockedUserId;
}
