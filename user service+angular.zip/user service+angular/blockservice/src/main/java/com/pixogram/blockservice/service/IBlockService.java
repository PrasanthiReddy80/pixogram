package com.pixogram.blockservice.service;

import java.util.List;

import com.pixogram.blockservice.entity.Block;
import com.pixogram.blockservice.model.BlockData;


public interface IBlockService {
	
	public List<Block> getall();
	public void save(BlockData block);
}
