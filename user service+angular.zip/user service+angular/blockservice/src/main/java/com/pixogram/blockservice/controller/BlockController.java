package com.pixogram.blockservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.pixogram.blockservice.model.BlockData;
import com.pixogram.blockservice.model.BlockModel;
import com.pixogram.blockservice.service.BlockService;

@RestController
public class BlockController {
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private BlockService blockService;
	
	@GetMapping("/block")
	public ResponseEntity<BlockModel> getall(){
		BlockModel result = new BlockModel();
		result.setBlocklist(this.blockService.getall());
		
		ResponseEntity<BlockModel> data = new ResponseEntity<BlockModel>(result, HttpStatus.OK);
		
		return data;
		
	}
	
	@PostMapping("/block")
	public boolean save(@RequestBody BlockData block) {
		this.blockService.save(block);
		return true;
	}
}
