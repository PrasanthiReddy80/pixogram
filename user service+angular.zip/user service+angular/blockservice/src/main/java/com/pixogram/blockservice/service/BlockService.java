package com.pixogram.blockservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.blockservice.entity.Block;
import com.pixogram.blockservice.model.BlockData;
import com.pixogram.blockservice.repository.BlockRepository;

@Service
public class BlockService implements IBlockService {
	
	@Autowired
	private BlockRepository blockRepository;
	
	public List<Block> getall(){
		List<Block> records = new ArrayList<Block>();
		records = this.blockRepository.findAll();
		return records;
		
	}

	@Override
	public void save(BlockData blockdata) {
		// TODO Auto-generated method stub
		Block data = new Block();
		data.setBlockedUserId(blockdata.getBlockedUserId());
		data.setUserId(blockdata.getUserId());
		this.blockRepository.save(data);
	}

}
