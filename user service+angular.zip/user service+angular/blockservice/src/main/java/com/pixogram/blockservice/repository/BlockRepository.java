package com.pixogram.blockservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pixogram.blockservice.entity.Block;


@Repository
public interface BlockRepository extends JpaRepository<Block, Integer> {

	

}
