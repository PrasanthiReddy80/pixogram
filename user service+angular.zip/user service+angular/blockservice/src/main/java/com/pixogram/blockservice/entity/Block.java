package com.pixogram.blockservice.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "block")
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Block implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(insertable = true)
	private Integer userId;
	
	@Id
	@Column(insertable = true)
	private Integer blockedUserId;
}
