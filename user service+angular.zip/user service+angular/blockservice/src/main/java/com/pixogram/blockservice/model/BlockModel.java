package com.pixogram.blockservice.model;

import java.util.List;

import com.pixogram.blockservice.entity.Block;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BlockModel {
	
	private List<Block> blocklist;
}
