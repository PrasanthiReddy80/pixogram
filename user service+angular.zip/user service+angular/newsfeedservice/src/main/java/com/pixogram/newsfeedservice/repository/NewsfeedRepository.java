package com.pixogram.newsfeedservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pixogram.newsfeedservice.entity.Newsfeed;

public interface NewsfeedRepository extends JpaRepository<Newsfeed, Integer> {

}
