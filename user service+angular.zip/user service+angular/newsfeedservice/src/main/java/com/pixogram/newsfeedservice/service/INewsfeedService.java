package com.pixogram.newsfeedservice.service;

import java.util.List;
import java.util.Optional;

import com.pixogram.newsfeedservice.entity.Newsfeed;
import com.pixogram.newsfeedservice.model.NewsfeedData;


public interface INewsfeedService {
	
	public List<Newsfeed> getall();
	public void save(NewsfeedData action);
	public Optional<Newsfeed> getWithId(Integer id);
	public void updateuser(NewsfeedData action);
}
