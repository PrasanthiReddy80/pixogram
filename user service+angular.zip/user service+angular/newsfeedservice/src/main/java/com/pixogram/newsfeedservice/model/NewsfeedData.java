package com.pixogram.newsfeedservice.model;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class NewsfeedData {
	
	private Integer id;
	private Integer userId;
	private String feed;
	private LocalDateTime createdOn;
}
