package com.pixogram.newsfeedservice.exception;

public class NewsfeedNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NewsfeedNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
}
