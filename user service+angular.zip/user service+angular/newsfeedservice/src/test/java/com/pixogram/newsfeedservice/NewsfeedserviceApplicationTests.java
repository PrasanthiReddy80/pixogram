package com.pixogram.newsfeedservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsfeedserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
