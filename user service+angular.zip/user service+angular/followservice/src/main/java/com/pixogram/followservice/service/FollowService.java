package com.pixogram.followservice.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pixogram.followservice.entity.Follow;
import com.pixogram.followservice.model.FollowData;
import com.pixogram.followservice.repository.FollowRepository;


@Service
public class FollowService implements IFollowService {
	
	@Autowired
	private FollowRepository followRepository;
	
	public List<Follow> getall(){
		List<Follow> records = this.followRepository.findAll();
		return records;
	}
	
	@Override
	public void save(FollowData follow) {
		// TODO Auto-generated method stub
		Follow data = new Follow();
		data.setFollowerId(follow.getFollowerId());
		data.setUserId(follow.getUserId());
		this.followRepository.save(data);
	}
	
	
}
