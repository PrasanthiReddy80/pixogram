package com.pixogram.followservice.service;

import java.util.List;


import com.pixogram.followservice.entity.Follow;
import com.pixogram.followservice.model.FollowData;

public interface IFollowService {
	
	public List<Follow> getall();
	public void save(FollowData follow);
	
}
