package com.cts.training.media.plumbing.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
@EnableEurekaClient
@EnableFeignClients("com.cts.training.media.plumbing.service.feignproxy")
@SpringBootApplication
public class PlumbingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlumbingServiceApplication.class, args);
	}

}
