package com.cts.training.media.plumbing.service.model;

import java.util.List;

import com.cts.training.media.plumbing.service.response.GalleryDisplayResponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MediaDetailsModel {

	private List<GalleryDisplayResponse> filelist;
}
