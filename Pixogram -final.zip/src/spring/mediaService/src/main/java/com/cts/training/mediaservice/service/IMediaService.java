package com.cts.training.mediaservice.service;

import java.util.List;
import java.util.Optional;

import com.cts.training.mediaservice.entity.Media;
import com.cts.training.mediaservice.model.MediaData;
import com.cts.training.mediaservice.model.MediaDataModel;


public interface IMediaService {

	public List<MediaData> getall(Integer userId);
	public void save(MediaData action);
	public Optional<Media> getWithId(Integer id);
	public void updateuser(MediaData action);
	
	
}	
	
