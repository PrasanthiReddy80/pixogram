package com.cts.training.followservice.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.training.followservice.entity.Follow;
import com.cts.training.followservice.repository.FollowRepository;
import com.cts.training.followservice.service.IFollowService;


@RestController
public class FollowController {

	// dependency
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private IFollowService followService;

	
	
	
	
	@GetMapping("/follow") // GET HTTP VERB
	public ResponseEntity<List<Follow>> exposeAll() {
		
		List<Follow> follow = this.followService.findAllFollows();
		ResponseEntity<List<Follow>> response = 
								new ResponseEntity<List<Follow>>(follow, HttpStatus.OK);
		
		
		return response;
	}	
	
	// REST method that will recieve a movie Id and return details of that movie
	@GetMapping("/follow/{followId}") // GET HTTP VERB
	public ResponseEntity<Follow> getById(@PathVariable Integer followId) {
		
		Follow action = this.followService.findFollowById(followId);
		ResponseEntity<Follow> response = 
				new ResponseEntity<Follow>(action, HttpStatus.OK);

		return response;
	}
	
	
	
	@PostMapping("/follow") // POST HTTP VERB
	public ResponseEntity<Follow> save(@RequestBody Follow follow) {
		this.followService.addFollow(follow);
		ResponseEntity<Follow> response = 
				new ResponseEntity<Follow>(follow, HttpStatus.OK);

		return response;
	}
	
	
	
	@PutMapping("/follow/{followId}")
	
		public ResponseEntity<Follow> saveUpdate(@PathVariable Integer followerId,@RequestBody Follow follow) {
		
		Follow f = new Follow (follow.getFollowerId(),follow.getUserId());

		if(!this.followService.updateFollow(f))
			throw new RuntimeException("could not update");
			
		ResponseEntity<Follow> response = 
				new ResponseEntity<Follow>(f, HttpStatus.OK);

		return response;
	}
	
	
	
	
	
	@DeleteMapping("/follow/{followId}")
	public ResponseEntity<Follow> delete(@PathVariable Integer followId) {
		
		Follow follow = this.followService.findFollowById(followId);
		this.followService.deleteFollow(followId);
		
		ResponseEntity<Follow> response = 
				new ResponseEntity<Follow>(follow, HttpStatus.OK);

		return response;
	}
	
	
	
}


















