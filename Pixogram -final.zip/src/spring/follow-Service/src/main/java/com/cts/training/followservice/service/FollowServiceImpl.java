package com.cts.training.followservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.training.followservice.entity.Follow;
import com.cts.training.followservice.repository.FollowRepository;
import com.cts.training.followservice.repository.FollowRepository;





// @Component
@Service
public class FollowServiceImpl implements IFollowService {

	@Autowired
	private FollowRepository followRepository;
	
	
	
	// get all
	@Override
	public List<Follow> findAllFollows() {
		// add additional logic
		return this.followRepository.findAll();
	}

	
	
	/// by id
	@Override
	public Follow findFollowById(Integer id) {
		// TODO Auto-generated method stub
		// resolves problem of null reference exception
		Optional<Follow> record =  this.followRepository.findById(id);
		// reduces the chance of NullException
		
		// can check if object is there
		Follow follow = new Follow();
		if(record.isPresent())
			follow = record.get();
		return follow;
		
	}
	
	
	
	@Override
	public boolean addFollow(Follow follow) {
		// TODO Auto-generated method stub
		this.followRepository.save(follow);
		return true;
	}
	
	
	@Override
	public boolean updateFollow(Follow follow) {
		// TODO Auto-generated method stub
		this.followRepository.save(follow);
		return true;
	}

	@Override
	public boolean deleteFollow(Integer id) {
		// TODO Auto-generated method stub
		this.followRepository.deleteById(id);
		return true;
	}
	
	


	
	
}
