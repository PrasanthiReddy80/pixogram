package com.cts.training.followservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.training.followservice.entity.Follow;



@Repository
public interface FollowRepository extends JpaRepository<Follow, Integer>{

}
