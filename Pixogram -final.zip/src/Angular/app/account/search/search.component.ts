import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserserviceService } from '../../services/DataServices/userservice.service';
import { SearchedUser } from 'src/app/model/searcheduser';
import { SearchedUserList } from 'src/app/model/searcheduserlist';
import { Follow } from 'src/app/model/follow.model';
import { subscribeOn } from 'rxjs/operators';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchtext : string;
  myFormGroup : FormGroup;
  result : string ;
  searchedUser:Array<SearchComponent>
  userList : Array<SearchedUser>;
  follow: Follow;

  constructor(formbuilder : FormBuilder, public router: Router, private userService: UserserviceService) {
    
    this.myFormGroup = formbuilder.group(
      {
        "keyword" : new FormControl(),
      }
    );

   }

   search(){
     this.searchtext = this.myFormGroup.controls['keyword'].value;
     this.userService.getSearchedUsers(this.searchtext).subscribe(
      (response : SearchedUserList) => {
        this.userList = response.userList;
        this.userList = this.userList.map(user =>{
          user.profileUrl = "http://localhost:8765/user-service/"+user.profileUrl;
          return user;
        });
        
      }
    );
   }
   doFollow(otherId:HTMLInputElement){
     this.follow=new Follow(Number(otherId.value),Number(sessionStorage.getItem("userid")));
     console.log(this.follow);
     this.userService.doFollow(this.follow).subscribe((Response)=>{

     });
  }
  doUnFollow(otherId:HTMLInputElement){
    console.log(Number(otherId.value));
    this.userService.doUnFollow(Number(otherId.value)).subscribe((Response)=>{

    });
  }
 
  getDetails(id : number){
    console.log(id);
    this.router.navigate(['/single-image/'+id])
   }
  
   

  ngOnInit() {
  }

}
