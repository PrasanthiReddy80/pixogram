import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { NewsFeed } from 'src/app/model/NewsFeed.model';
import { UserRegistrationService } from 'src/app/services/user-registration.service';

@Component({
  selector: 'app-newsfeeds',
  templateUrl: './newsfeeds.component.html',
  styleUrls: ['./newsfeeds.component.css']
})
export class NewsfeedsComponent implements OnInit {
    feeds:NewsFeed[]
  constructor(public auth : AuthenticationService,public userservice:UserRegistrationService) { }
  message():void{
    
    alert("Logged out!!!");
    this.auth.logout();
  }
  
  ngOnInit() {
    
    }

  }

