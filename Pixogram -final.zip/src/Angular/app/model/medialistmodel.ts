import { Media } from './media';


export class MediaListModel{
   
    filelist : Array<Media>;
}