export class UserId{
         id : number;
		 firstname :string;
		 lastname :string;
		 profile :any;
     constructor(id,firstname,lastname,profile){
        
         this.firstname = firstname;
         this.lastname = lastname;
         this.profile = profile;
     }

}