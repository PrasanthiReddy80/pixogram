export class NewsFeed{
    userId:number;
    feed:string;
    createdOn:string;
}