export class Follow{
    userId:Number;
    followerId:Number;
    constructor(userId,followerId){
        this.userId=userId;
        this.followerId=followerId;
    }
}