export class User{
   
	usernames : Array<String>;
}