import { SearchedUser } from './searcheduser';

export class SearchedUserList{

    userList : Array<SearchedUser>;
}