import { Injectable } from '@angular/core';
import { UserserviceService } from './DataServices/userservice.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserRegistrationDetails } from '../model/user-registration';
import {map} from 'rxjs/operators';
import { ResponseData } from '../model/response.model';
const VALIDATION_URL = "http://localhost:8765/user-service/login";

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {
  Id : number ;
  userlist : Array<UserRegistrationDetails>;
  constructor(public ser : UserserviceService,public http : HttpClient) { 
    
  }
  authenticate(username : string, password : string) {
    // create a security token
    // create a security token
    let authenticationToken = "Basic " + window.btoa(username + ":" + password);
    console.log(authenticationToken);
 
    let headers = new HttpHeaders({
      Authorization : authenticationToken
    });
    console.log("calling server")
    // send the request
    return this.http.get(VALIDATION_URL, {headers}).pipe(
      // success function
      map((successData : ResponseData)=>{
        sessionStorage.setItem("user",username);
        // save the token
        let reponseData : ResponseData =successData;
        sessionStorage.setItem("token", authenticationToken);
        sessionStorage.setItem("userid", reponseData.userId + "");
        sessionStorage.setItem("profilepic", reponseData.profilepic);
        return successData;
      }),
      // failure function
      map(failureData=>{
        // console message 
        return failureData;
      })
    );
   }
 
   getAuthenticationToken(){
     if(this.isUserLoggedIn())
       return sessionStorage.getItem("token");
     return null; 
   }
 
   isUserLoggedIn(): boolean{
     let user = sessionStorage.getItem('user');
     if(user == null)
       return false;
     return true;  
   }
   getId():number{
     let a = Number(sessionStorage.getItem('uid'));
     console.log("in getid"+this.Id)
     return a;
   }
   getPic():string{
    let a = sessionStorage.getItem('profilepic');
   
    return a;
  }
   
   
   logout(){
     sessionStorage.removeItem('token');
     sessionStorage.removeItem('user');
     sessionStorage.removeItem('uid');
     
   }
 
   getUserDetails():string{
     let user = sessionStorage.getItem('user');
     return user;
   }
   
 }
 