import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UserRegistrationDetails } from 'src/app/model/user-registration';
import { User } from 'src/app/model/user';
import { UserId } from 'src/app/model/userid';
import { Follow } from 'src/app/model/follow.model';
import { Observable } from 'rxjs';
import { NewsFeed } from 'src/app/model/NewsFeed.model';
const UsernamesURL = "http://localhost:8765/user-service/usernames";
const API_URL = "http://localhost:8765/user-service/users";
const REG_URL = "http://localhost:8765/user-service/register";
const MISC_URL = "http://localhost:8765/misc-plumbing";
const UseridURL = "http://localhost:8765/user-service/custom";
const Follow_URL="http://localhost:8765/follow-service";

@Injectable({
  providedIn: 'root'
})


export class UserserviceService {
Ret_url="http://localhost:8765/media-plumbing/media";
News_Feed:"http://localhost:9091/newsfeeds";

  user : UserId;
  constructor(public http : HttpClient) {


   }



   doFollow(follow:Follow):any{
    return this.http.post(Follow_URL+"/follow",follow);
  }
  doUnFollow(other:number):any{
    console.log(other);
    return this.http.delete(Follow_URL+"/unfollow/mine/"+sessionStorage.getItem("userid")+"/other/"+other);
  }

   getSearchedUsers(searchText : string){
    return this.http.get(MISC_URL + "/searched-users/" + searchText + "/myid/" + sessionStorage.getItem("userid"));
  }
 getAllUsernames():any{
   return this.http.get(UsernamesURL);
 }
 getId():any {
    
  let name = sessionStorage.getItem("username");
  return this.http.get(UseridURL+"/"+name);
 
}

  getAllUsers():any{
    return this.http.get(API_URL);
  }

  getUser(id:number):any{
    return this.http.get(API_URL+"/"+id);
  }

  addUser(user:UserRegistrationDetails):any{
    return this.http.post(REG_URL,user);
  }

  delete(id:number){
    this.http.delete(API_URL+"/"+id);
  }

  update(id:number,user:UserRegistrationDetails):any{
    return this.http.put(API_URL+"/"+id,user);
  }
  getAllFeed(userid:string):Observable<NewsFeed[]>{
     return this.http.get<NewsFeed[]>(this.News_Feed+userid);
  }
}
